# Z.AGENT Dashboard

Interface web Next.js pour surveiller et contrôler l'agent Z.AGENT.

## Installation

```bash
cd z-agent-dashboard
bun install   # ou: npm install
bun run dev   # ou: npm run dev
```

Le dashboard se lance sur http://localhost:3000 et se connecte à l'API agent sur http://localhost:8765.

## Configuration

Si votre API agent est sur une autre machine, définissez :

```bash
export NEXT_PUBLIC_AGENT_API=http://192.168.1.10:8765
```

## Fonctionnalités

- Statut de l'agent en temps réel (WebSocket)
- Soumission de tâches en langage naturel
- Historique des tâches avec plans détaillés
- Logs en streaming
- Galerie de captures d'écran
- Contrôle pause / reprendre / stop
