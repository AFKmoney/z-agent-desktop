#!/bin/bash
# Z.AGENT quick start script
set -e
cd "$(dirname "$0")"

if [ ! -d venv ]; then
    echo "First run: creating virtualenv..."
    python3 -m venv venv
fi

source venv/bin/activate
pip install -r requirements.txt -q
playwright install chromium 2>/dev/null || true

if [ ! -f .env ]; then
    echo "⚠️  .env file not found. Copy .env.example to .env and fill in your keys."
    echo "   Read the documentation for details."
    exit 1
fi

python main.py "$@"
