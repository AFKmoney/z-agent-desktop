@echo off
REM Z.AGENT quick start script for Windows
cd /d "%~dp0"

if not exist venv (
    echo First run: creating virtualenv...
    python -m venv venv
)

call venv\Scripts\activate
pip install -r requirements.txt -q
playwright install chromium

if not exist .env (
    echo WARNING: .env file not found. Copy .env.example to .env and fill in your keys.
    exit /b 1
)

python main.py %*
